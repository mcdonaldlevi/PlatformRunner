﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ProjectileManager))]
public class ShootProjectile : MonoBehaviour
{
    public List<string> targetTagNames;                 // The tag names of the targets to shoot at.
    public float fireRate;                              // Rate of fire per second.
    public float projectileSpeed;                       // The time it takes for the projectile to travel.

    private SpriteRenderer _spriteRenderer;             // Sprite renderer used to determine which direction the game object is facing.
    private ProjectileManager _projectileManager;       // This game object's projectile to manage.
    private float _cameraViewWidth;

    private void Awake()
    {
        Debug.Assert(targetTagNames != default(List<string>),
            ("Error, no targets are attached to the ShootProjectile script in object" +
            gameObject.name + "Please set the targets or remove the script."));
    }

    private IEnumerator Start()
    {
        // Set Fire rate (shots/second)
        fireRate = 1f / fireRate;

        _cameraViewWidth = 2f * FindObjectOfType<Camera>().orthographicSize;

        _projectileManager = GetComponent<ProjectileManager>();

        _spriteRenderer = GetComponent<SpriteRenderer>();

        while (gameObject.activeInHierarchy)
        {
            ProjectileMove behavior = _projectileManager.GetProjectile();
            yield return StartCoroutine(Shoot(behavior));
            yield return new WaitForSeconds(fireRate);
        }
    }

    /// <summary>
    /// Coroutine that shoots a pooled projectile until the parent gameObject is deactivated.
    /// </summary>
    /// <returns></returns>
    private IEnumerator Shoot(ProjectileMove behavior)
    {
        Debug.Log("shoot");
        WaitForFixedUpdate wait = new WaitForFixedUpdate();

        // START POSITION


        // END POSITION
        int direction = _spriteRenderer.flipX ? -1 : 1;
        float xPos = direction * (_cameraViewWidth);
        float yPos = transform.position.y;
        float zPos = transform.position.z;

        Vector3 endPos = new Vector3(xPos, yPos, zPos);

        yield return behavior.Move(transform.position, endPos, projectileSpeed);

    }
}
