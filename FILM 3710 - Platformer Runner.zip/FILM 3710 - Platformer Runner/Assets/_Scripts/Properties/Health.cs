﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    public int maxHP;                                   // Entity's maximum health.
    public float repeatDamagePeriod;                    // The amount of time to wait before dealing damage again.

    private int _currentHP;                             // The current health of the entity.
    private bool _canDamage;                            
    private SpriteRenderer _spriteRenderer;                             

    public int CurrentHP
    {
        get
        {
            return _currentHP;
        }
    }

    private void Awake()
    {
        Debug.Assert(0 != maxHP, "The maximum HP CANNOT be zero!");
    }

    void Start()
    {
        _currentHP = maxHP;
        _canDamage = true;
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        CheckStatus();
    }

    /// <summary>
    /// Updates the entity's current status.
    /// </summary>
    private void CheckStatus()
    {
        if (_currentHP > maxHP)
        {
            _currentHP = maxHP;
        }
        if (_currentHP < 0)
        {
            _currentHP = 0;
        }
        if (_currentHP == 0)
        {
            Debug.Log(gameObject.name + " died!");
            gameObject.SetActive(false);
        }
    }

    /// <summary>
    /// Adds health for the player with a parameter value.
    /// </summary>
    /// <param name="health">The health to add.</param>
    public void Heal(int health)
    {
        if (gameObject.activeInHierarchy)
        {
            _currentHP += health;
        }
    }

    /// <summary>
    /// Removes health from the player with a parameter value.
    /// </summary>
    /// <param name="damage">The amount of damage to take.</param>
    public void ReceiveDamage(int damage)
    {
        if (gameObject.activeInHierarchy && _canDamage)
        {
            _currentHP -= damage;
            StartCoroutine("DisableDamageCoroutine");
            //StartCoroutine(FlashColor(_spriteRenderer.color, flash));
        }
    }

    /// <summary>
    /// Coroutine that waits specified amount of time before 
    /// </summary>
    /// <returns></returns>
    private IEnumerator DisableDamageCoroutine()
    {
        _canDamage = false;
        yield return new WaitForSeconds(repeatDamagePeriod);
        Debug.Log("Disabled Damage on " + gameObject.name + " for " + repeatDamagePeriod + " seconds");
        _canDamage = true;
    }

    /// <summary>
    /// Coroutine that makes the gameObject flash a particular color.
    /// </summary>
    /// <returns></returns>
    private IEnumerator FlashColor(Color original, Color flash)
    {
        float flashLength = .1f;
        int numberOfFlashes = 5;

        Debug.Log("Flashing color of " + gameObject.name);
        for (int i = 0; i < numberOfFlashes; i++)
        {
            _spriteRenderer.material.color = flash;
            yield return new WaitForSeconds(flashLength);
            _spriteRenderer.material.color = original;
            yield return new WaitForSeconds(flashLength);
        }
    }
}
