﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damage : MonoBehaviour
{
    public int damage;                                      // The total damage dealt.
    public List<string> tagNames;                           // Tag names of the gameObjects that can be damaged.
    //public Color damageColor;                               // The color of the entity to flash when damage is taken.
    public bool deactivateOnCollision;                      // Deactivate the gameObject in hiearchy upon colliding with tag.

    private bool _canDamage;

    private void Start()
    {
        _canDamage = true;
        //damageColor = (damageColor == null) ? new Color(255, 0, 0) : damageColor;
    }

    /// <summary>
    /// Deactivates the object if enabled
    /// </summary>
    /// <param name="collision"></param>
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (tagNames.Contains(collision.gameObject.tag) && _canDamage)
        {
            gameObject.SetActive(!deactivateOnCollision);
            Debug.Log(collision.gameObject.name + " Received " + damage + " damage from " + gameObject.name + "!");
            collision.gameObject.GetComponent<Health>().ReceiveDamage(damage);
        }
    }
}
