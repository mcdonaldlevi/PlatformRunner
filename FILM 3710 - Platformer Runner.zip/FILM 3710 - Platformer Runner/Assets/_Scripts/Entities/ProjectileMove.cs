﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Update projectile speed and direction over time.
/// </summary>
public class ProjectileMove : MonoBehaviour
{
    public bool hideOnCollision;        // Hides the projectile after colliding.

    /// <summary>
    /// Stops the move corouting and de-activates the projectile once out of camera view.
    /// </summary>
    private void OnBecameInvisible()
    {
        gameObject.SetActive(false);
    }

    /// <summary>
    /// Hides the projectile after colliding with a Collider2D depending on the Inspector
    /// member variable hideOnCollision
    /// </summary>
    /// <param name="collision">The collider component of the colliding gameobject.</param>
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (hideOnCollision)
        {
            gameObject.SetActive(false);
        }
    }

    /// <summary>
    /// Coroutine that moves the projectile from startPos parameter to the endPos parameter
    /// over a specified time.  
    /// </summary>
    /// <param name="startPos">Position where the projectile will appear.</param>
    /// <param name="endPos">Position where the projectile will disappear.</param>
    /// <param name="time">The total time that it takes the projectile to travel.</param>
    /// <returns></returns>
    public IEnumerator Move(Vector3 startPos, Vector3 endPos, float time)
    {
        WaitForFixedUpdate wait;
        gameObject.SetActive(true);

        float currentTime = 0.0f;
        float rate = 1.0f / time;

        while (currentTime < 1.0f)
        {
            wait = new WaitForFixedUpdate();

            currentTime += Time.smoothDeltaTime * rate;
            transform.position = Vector3.Lerp(startPos, endPos, currentTime);
            yield return wait;
        }
        gameObject.SetActive(false);
    }
}
