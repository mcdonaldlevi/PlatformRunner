﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackAndForth : MonoBehaviour
{
    public float movementTime;                                  // Total time from point A to point B.
    public float pauseMovementTime;                             // The pause time before moving to other direction.
    public bool flipSpriteDirection;                            // If the direction of the GameObject should be switched after moving.
    public float switchDirectionTime;                           // The amount of time before turning around.
    public Vector2 moveDistance;                                // The distance the enemy will move in the x or y direction.

    private Vector3 _pointA;                                    // Starting point of the game object.
    private Vector3 _pointB;                                    // Ending point of the game object's movement.
    private Transform _transform;                               // The game object's transform.
    private SpriteRenderer _spriteRenderer;                     // The game object's sprite renderer.

    private void Awake()
    {
        // The move distance must be set for the game object to move.
        Debug.Assert(moveDistance != default(Vector2));
    }

    IEnumerator Start()
    {
        // Get gameobject components.
        _transform = gameObject.GetComponent<Transform>();
        _spriteRenderer = gameObject.GetComponent<SpriteRenderer>();

        // Set the start and end position.
        _pointA = new Vector3(_transform.position.x, _transform.position.y, 0);
        _pointB = new Vector3(_pointA.x + moveDistance.x, _pointA.y + moveDistance.y, 0);

        // Move back and forth while the gameObject is active.
        while (gameObject.activeInHierarchy)
        {
            yield return StartCoroutine(Move(_pointA, _pointB));
            yield return StartCoroutine(Move(_pointB, _pointA));
        }
    }

    /// <summary>
    /// A coroutine that moves the game object from initial position to
    /// a final point that is assigned in the inspector.
    /// </summary>
    /// <param name="transform">The game object's transform.</param>
    /// <param name="startPos">The start position of the game object.</param>
    /// <param name="endPos">The ending position of the game object.</param>
    /// <param name="time">Total time of the movement from the start position to end position.</param>
    /// <returns></returns>
    private IEnumerator Move(Vector3 startPos, Vector3 endPos)
    {
        WaitForFixedUpdate wait = new WaitForFixedUpdate();

        float currentTime = 0.0f;
        float rate = 1.0f / movementTime;
        while (currentTime < 1.0f)
        {
            currentTime += Time.smoothDeltaTime * rate;
            _transform.position = Vector3.Lerp(startPos, endPos, currentTime);
            yield return wait;
        }

        StartCoroutine("SwitchDirection");
        yield return new WaitForSeconds(pauseMovementTime);
    }

    /// <summary>
    /// A coroutine that switches the direction of the object if value of switchDirectionTime 
    /// is set to true in the inspector.
    /// 
    /// If the value of switchDirection is true, then the coroutine waits for the switchDirectionTime
    /// and then switches the direction of that sprite.
    /// </summary>
    /// <returns></returns>
    private IEnumerator SwitchDirection()
    {
        if (flipSpriteDirection == true)
        {
            yield return new WaitForSeconds(switchDirectionTime);
            _spriteRenderer.flipX = !_spriteRenderer.flipX;
        }
    }
}
