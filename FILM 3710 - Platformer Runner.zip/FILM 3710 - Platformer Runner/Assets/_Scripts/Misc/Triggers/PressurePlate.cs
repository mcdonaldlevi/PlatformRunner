﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Defines a pressure plate game object.
/// </summary>
[System.Serializable]
public class PressurePlate : BaseTrigger
{
    /// <summary>
    /// Determines if the state of the target should be set/switched on enter.
    /// </summary>
    [SerializeField] private bool switchStateOnEnter;

    /// <summary>
    /// Determines if the state of the target should be set/switched on exit.
    /// </summary>
    [SerializeField] private bool switchStateOnExit;

    /// <summary>
    /// Activates the platform after colliding with a valid gameobject.
    /// </summary>
    /// <param name="collision">The game object that the pressure plate collided with.</param>
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!triggerAction.isActive && tagNames.Contains(collision.gameObject.tag))
        {
            triggerAction.SwitchState();

            if (switchStateOnEnter)
            {
                targetAction.SwitchState();
            }
        }
    }

    /// <summary>
    /// Deactivates the platform after a valid game object leaves the collision.
    /// </summary>
    /// <param name="collision"></param>
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (triggerAction.isActive && tagNames.Contains(collision.gameObject.tag))
        {
            triggerAction.SwitchState();

            if (switchStateOnExit)
            {
                targetAction.SwitchState();
            }
        }
    }
}


