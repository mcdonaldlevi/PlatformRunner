﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Defines the behavior of some GameObject when activated by a BaseTrigger.
/// </summary>
public class Fall : BaseAction
{
    [SerializeField] public float time;

    private Camera _camera;

    private void Start()
    {
        _camera = FindObjectOfType<Camera>();
    }

    /// <summary>
    /// Hides the game object after going off of the screen.
    /// </summary>
    private void OnBecameInvisible()
    {
        gameObject.SetActive(false);
    }

    /// <summary>
    /// Moves the game object downwards at a constant speed.
    /// </summary>
    /// <param name="gameObject">The game object that is falling.</param>
    /// <returns></returns>
    public override IEnumerator Active(GameObject gameObject)
    {
        WaitForFixedUpdate wait;

        float currentTime = 0f;
        float rate = 1.0f / time;

        if (pauseOnActive) { yield return pause; }

        while (currentTime < 1.0f)
        {
            wait = new WaitForFixedUpdate();

            currentTime += Time.smoothDeltaTime * rate;
            gameObject.transform.position = Vector3.Lerp(gameObject.transform.position, CalculateTargetPoint(), currentTime);
            yield return wait;
        }
    }

    /// <summary>
    /// Determiens the point where the game object should fall.
    /// </summary>
    /// <returns></returns>
    private Vector3 CalculateTargetPoint()
    {
        float height = 2f * _camera.orthographicSize;
        return new Vector3(gameObject.transform.position.x, -height, gameObject.transform.position.z);
    }
}
