﻿using System.Collections;
using UnityEngine;

/// <summary>
/// Defines the behavior of some GameObject when activated by a BaseTrigger.
/// </summary>
[System.Serializable]
public class Rescale : BaseAction
{
    [SerializeField] private float activationTime;                // Amount of time it takes for the platform to fully scale to it's activatedScale.

    [SerializeField] private Vector3 activeScale;

    [SerializeField] private Vector3 inactiveScale;

    private void Start()
    {
        Debug.Assert(activationTime != 0, "Error, activation time cannot be set to zero!");

        if (initializedActive)
        {
            gameObject.transform.localScale = activeScale;
        }
        else
        {
            gameObject.transform.localScale = inactiveScale;
        }
    }

    /// <summary>
    /// Scales the gameObject from <see cref="unactivatedScale"/> to it's <see cref="activatedScale"/>.
    /// </summary>
    public override IEnumerator Active(GameObject gameObject)
    {
        WaitForFixedUpdate wait;

        float currentTime = 0f;
        float rate = 1.0f / activationTime;

        if (pauseOnActive) { yield return pause; }

        while (currentTime < 1.0f)
        {
            wait = new WaitForFixedUpdate();

            currentTime += Time.smoothDeltaTime * rate;
            gameObject.transform.localScale = Vector3.Lerp(gameObject.transform.localScale, activeScale, currentTime);
            yield return wait;
        }
    }

    /// <summary>
    /// Scales the gameObject from <see cref="activatedScale"/> to it's <see cref="unactivatedScale"/>.
    /// </summary>
    public override IEnumerator Inactive(GameObject gameObject)
    {
        WaitForFixedUpdate wait;

        float currentTime = 0f;
        float rate = 1.0f / activationTime;

        if (pauseOnInactive) { yield return pause; }

        while (currentTime < 1.0f)
        {
            wait = new WaitForFixedUpdate();

            currentTime += Time.smoothDeltaTime * rate;
            gameObject.transform.localScale = Vector3.Lerp(gameObject.transform.localScale, inactiveScale, currentTime);
            yield return wait;
        }
    }
}
