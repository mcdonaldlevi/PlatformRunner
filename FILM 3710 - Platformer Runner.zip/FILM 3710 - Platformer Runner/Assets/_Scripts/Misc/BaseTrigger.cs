﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// The game object that can trigger some event or action.
/// </summary>
[System.Serializable]
public class BaseTrigger : MonoBehaviour
{
    [SerializeField] public BaseAction target;

    [HideInInspector] public BaseAction triggerAction;

    [HideInInspector] public BaseAction targetAction;

    /// <summary>
    /// Gameobjects with tag names that can affect the presure plate.
    /// </summary>
    [SerializeField] public List<string> tagNames;

    private void Awake()
    {
        triggerAction = gameObject.GetComponentInChildren<BaseAction>();
        targetAction = target.GetComponent<BaseAction>();
    }
}
