﻿
using System.Collections;
using UnityEngine;
/// <summary>
/// Interface that defines the actions of some trigger.
/// </summary>
public abstract class BaseAction : MonoBehaviour
{
    [SerializeField] internal bool initializedActive;

    [SerializeField] internal bool pauseOnActive;

    [SerializeField] internal bool pauseOnInactive;

    [SerializeField] private float pauseTime;                     // The amount of time that it takes for the gameobject to switch states.

    private bool _isActive;

    /// <summary>
    /// The current state of the gameobject.
    /// </summary>
    internal IEnumerator state;

    /// <summary>
    /// The amount of time to pause in a coroutine.
    /// </summary>
    internal WaitForSeconds pause;

    public bool isActive { get { return _isActive; } }

    public void Awake()
    {
        switch (initializedActive)
        {
            case true:
                state = Active(gameObject);
                break;

            case false:
                state = Inactive(gameObject);
                break;
        }

        _isActive = initializedActive;
    }

    /// <summary>
    /// Switches the state of the action.
    /// </summary>
    public void SwitchState()
    {
        StopCoroutine(state);

        state = (_isActive) ? Inactive(gameObject) : Active(gameObject);

        _isActive = !_isActive;

        StartCoroutine(state);
    }

    /// <summary>
    /// The behavior of the gameobject when activated.
    /// </summary>
    /// <param name="gameObject">The gameobject that will be modified when the trigger is activated.</param>
    /// <returns>IEnumerator to be run using a coroutine.</returns>
    public virtual IEnumerator Active(GameObject gameObject) { yield return null; }

    /// <summary>
    /// The behavior of the gameobject when deactivated.
    /// </summary>
    /// <param name="gameObject">The gameobject that will be modified when the trigger is activated.</param>
    /// <returns>IEnumerator to be run using a coroutine.</returns>
    public virtual IEnumerator Inactive(GameObject gameObject) { yield return null; }
}