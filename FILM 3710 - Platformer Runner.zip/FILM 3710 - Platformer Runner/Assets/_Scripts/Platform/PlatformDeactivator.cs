﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Script attached to platform that deactivates the platform once it is out of range.
/// </summary>
public class PlatformDeactivator : MonoBehaviour
{
    public GameObject deactivationPoint;

    // Use this for initialization
    void Start()
    {
        deactivationPoint = GameObject.Find("PlatformDeactivationPoint");
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x < deactivationPoint.transform.position.x)
        {
            gameObject.SetActive(false);
        }
    }
}
