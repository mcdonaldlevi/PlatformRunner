﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour
{
    private Queue<GameObject> _menuQueue = new Queue<GameObject>();

    /// <summary>
    /// Loads the scene provided a file name parameter.
    /// </summary>
    /// <param name="sceneName">The name of the scene to load.</param>
    public void LoadScene(string sceneName)
    {
        SceneManager.LoadSceneAsync(sceneName);
    }

    /// <summary>
    /// Displays a canvas name.
    /// </summary>
    /// <param name="menuName"></param>
    public void Hide(GameObject menu)
    {
        menu.SetActive(false);
    }


    public void Display(GameObject menu)
    {
        menu.SetActive(true);
    }

    public void Exit()
    {
        Application.Quit();
    }
}
