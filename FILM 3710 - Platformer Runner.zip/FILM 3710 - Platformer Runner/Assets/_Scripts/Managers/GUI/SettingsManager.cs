﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

/// <summary>
/// Contains the logic of the buttons.
/// </summary>
public class SettingsManager : MonoBehaviour
{
    bool fpsEnabled= false;

    /// <summary>
    /// Adjusts the program volume according to the provided Slider parameter.
    /// </summary>
    /// <param name="slider">The Slider object that has the program volume value.</param>
    public void AdjustVolume(Slider slider)
    {
        AudioListener.volume = slider.value;
    }

    public void ToggleFpsCounter(GameObject FPSCounter, Text status)
    {
        fpsEnabled = !fpsEnabled;
        FPSCounter.SetActive(fpsEnabled);

        if (enabled)
        {
            status.text = "Enabled";
        }
        else
        {
            status.text = "Disabled";
        }
    }
}
