﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Class that generates platforms using an object pooler.
/// </summary>
public class PlatformManager : MonoBehaviour
{
    public Transform activationPoint;                       // The generation point of the PlatformManager.

    public float minHorizontalDistance;                     // Min horizontal distance between platforms.
    public float maxHorizontalDistance;                     // Max horizontal distance between platforms.

    private float minVerticalDistance;                      // Min vertical distance between platforms.
    private float maxVerticalDistance;                      // Max vertical distance between platforms.
    public Transform maxVerticalPosition;                   // The maximum vertical position a platform can be placed.

    public ObjectPooler[] objectPools;                      // The object pooling object that activates and deactivates.

    private float platformWidth;
    private float[] platformWidths;                         // Array of the widths platforms used to determine distance.


    void Start()
    {
        InitializePlatformWidth();
        InitializePlatformHeight();
    }

    /// <summary>
    /// Initializes the platform width array which is used as the minimum distance
    /// the Platform Manager should randomize the next platforms position.
    /// </summary>
    void InitializePlatformWidth()
    {
        // Initialize array of platform widths.
        platformWidths = new float[objectPools.Length];

        for (int i = 0; i < objectPools.Length; i++)
        {
            // Get the pooled object within the array of object pools.
            platformWidths[i] = objectPools[i].pooledObject.GetComponent<BoxCollider2D>().size.x;
        }
    }

    void InitializePlatformHeight()
    {
        minVerticalDistance = transform.position.y;
        maxVerticalDistance = maxVerticalPosition.position.y;
    }

    void Update()
    {
        // If the platform manager's position is less than the generation point.
        if (transform.position.x < activationPoint.position.x)
        {
            float betweenDistanceX = Random.Range(minHorizontalDistance, maxHorizontalDistance);
            float betweenDistanceY = GetVerticalPosition();
            int platformIndex = RandomPlatformSelector();

            SetManagerPosition(betweenDistanceX, betweenDistanceY, platformIndex);

            GameObject platform = objectPools[platformIndex].GetPooledObject();

            SetPlatformPosition(platform);
        }
    }


    /// <summary>
    /// Calculates the y position of the platform.
    /// </summary>
    /// <returns></returns>
    private float GetVerticalPosition()
    {
        float yPos = Random.Range(maxVerticalDistance, -maxVerticalDistance);
        if (yPos > maxVerticalDistance)
        {
            return maxVerticalDistance;
        }
        if (yPos < minVerticalDistance)
        {
            return minVerticalDistance;
        }
        else
        {
            return yPos;
        }
    }


    /// <summary>
    /// Sets the position of the platform generator.
    /// </summary>
    private void SetManagerPosition(float betweenDistanceX, float betweenDistanceY, int platformIndex)
    {
        float xPos = transform.position.x + platformWidths[platformIndex] + betweenDistanceX;
        float yPos = transform.position.y + betweenDistanceY;
        transform.position = new Vector3(xPos, yPos, 0);
    }


    /// <summary>
    /// Sets the object pooled platform's position, rotation, and activates it.
    /// </summary>
    /// <param name="platform">The GameObject platform from the objectPools array.</param>
    private void SetPlatformPosition(GameObject platform)
    {
        platform.transform.position = transform.position;
        platform.transform.rotation = transform.rotation;
        platform.SetActive(true);
    }


    /// <summary>
    /// Randomly selects a platform in array of object pools.
    /// </summary>
    /// <returns></returns>
    private int RandomPlatformSelector()
    {
        int randomPlatform = Random.Range(0, objectPools.Length);
        return randomPlatform;
    }
}
