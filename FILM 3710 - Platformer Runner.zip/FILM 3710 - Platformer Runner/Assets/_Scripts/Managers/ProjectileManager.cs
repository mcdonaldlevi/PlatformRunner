﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileManager : MonoBehaviour
{
    public GameObject projectile;                               // The base game object projectile prefab to manage.

    private List<GameObject> _projectileGameObjs;                   // Projectile game objects.
    private List<ProjectileMove> _projectileBehaviors;              // Projectile behaviors mapped to the projectile game object.

    private const int DEFAULT_PROJECTILES = 10;

    private void Awake()
    {
        _projectileBehaviors = new List<ProjectileMove>(DEFAULT_PROJECTILES);
        _projectileGameObjs = new List<GameObject>(DEFAULT_PROJECTILES);
        CreateNewProjectiles(DEFAULT_PROJECTILES);
    }

    /// <summary>
    /// Creates a new projectile GameObjects and scripts according to the provided parameter.
    /// </summary>
    /// <param name="count"></param>
    private void CreateNewProjectiles(int count)
    {
        for (int i = 0; i < count; i++)
        {
            // Create new projectile
            GameObject newProj = Instantiate(projectile);
            newProj.transform.position = transform.position;
            newProj.SetActive(false);

            ProjectileMove newProjProp = newProj.GetComponent<ProjectileMove>();

            // Add new GameObject to the list
            _projectileGameObjs.Add(newProj);

            // Add reference to the new GameObject's associated MoveProjectile script.
            _projectileBehaviors.Add(newProjProp);
        }
    }

    /// <summary>
    /// Returns an enumeration of projectiles that are not active in hierarchy that can be used by
    /// some entity that needs to modify the behavior of the projectile.
    /// </summary>
    /// <returns></returns>
    public ProjectileMove GetProjectile()
    {
        for (int i = 0; i < _projectileGameObjs.Count - 1; i++)
        {
            if (!_projectileGameObjs[i].activeInHierarchy)
            {
                return _projectileBehaviors[i];
            }
        }
        CreateNewProjectiles(1);
        return _projectileBehaviors[_projectileBehaviors.Count - 1];
    }
}
