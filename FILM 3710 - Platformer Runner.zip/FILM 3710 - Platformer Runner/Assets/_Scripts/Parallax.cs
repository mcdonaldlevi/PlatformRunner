﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// A script that creates a parallax effect to a game object's child elements.
/// </summary>
public class Parallax : MonoBehaviour
{
    public int movementTime;

    private float _backgroundSize;                   // The background size of the image.
    private LinkedList<Transform> _layers;          // Layers in the child of the empty gameobject.
    private Vector3 _swapPoint;

    IEnumerator Start()
    {
        movementTime = (movementTime != 0) ? movementTime : 1;                   // Speed defaults to 1 if it is 0.
        InitializeImages();

        while (gameObject.activeInHierarchy)
        {
            yield return StartCoroutine(Move(transform.position, -_backgroundSize));
        }
    }

    private void InitializeImages()
    {
        int imageCount = transform.childCount;

        _layers = new LinkedList<Transform>();
        for (int i = 0; i < imageCount; i++)
        {
            _layers.AddLast(transform.GetChild(i));
        }

        // Set the left initial position.
        _swapPoint = _layers.Last.Value.position;

        _backgroundSize = _layers.Last.Value.position.x;
    }

    private void SwapBackground()
    {
        LinkedListNode<Transform> first = _layers.First;
        LinkedListNode<Transform> last = _layers.Last;
        _layers.First.Value.position = _swapPoint;

        // Remove the first and last
        _layers.RemoveFirst();
        _layers.RemoveLast();

        // Swap the two node positions.
        _layers.AddFirst(last);
        _layers.AddLast(first);
    }

    private IEnumerator Move(Vector3 startPos, float distance)
    {
        float currentTime = 0.0f;
        float rate = 1.0f / movementTime;
        Vector3 endPos = new Vector3(startPos.x + distance, startPos.y, startPos.z);

        while (currentTime < 1.0f)
        {
            WaitForFixedUpdate wait = new WaitForFixedUpdate();

            currentTime += Time.smoothDeltaTime * rate;
            transform.position = Vector3.Lerp(startPos, endPos, currentTime);
            yield return wait;
        }
        SwapBackground();
    }
}
