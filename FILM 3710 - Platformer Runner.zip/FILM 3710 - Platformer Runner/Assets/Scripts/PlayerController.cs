﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [HideInInspector]
    public bool jump;

    public string playerName;                           // The name of the player.

    public float moveSpeed;                             // The speed of the player relative to the world.
    public float maxSpeed;                              // The max speed of the player relative to the world.
    public float jumpForce;                             // The jump force of the player.
    public LayerMask groundLayerMask;                   // The layermask of the ground.

    // Player State
    public bool grounded;

    // Controllers
    private Animator _animator;
    private CircleCollider2D _collider;
    private Rigidbody2D _rigidBody2D;


    /// <summary>
    /// Initialize the components before the Update is called.
    /// </summary>
	void Awake()
    {
        jump = false;

        // Get Components
        _animator = GetComponent<Animator>();
        _collider = GetComponent<CircleCollider2D>();
        _rigidBody2D = GetComponent<Rigidbody2D>();
    }

    /// <summary>
    /// Sets the player grounded state and checks for jump input once per frame.
    /// </summary>
    void Update()
    {
        SetSpeed();
        SetGrounded();
        if (grounded)
        {
            CheckJump();
        }
    }

    /// <summary>
    /// Updates the player physics in sync with the physics engine.
    /// </summary>
    private void FixedUpdate()
    {
        // Get horizontal axis 
        float displacement = Input.GetAxis("Horizontal");

        // Set the animator controller to play over distance.
        // Must use positive float to set animation speed 
        // (negative animation speed makes not sense).
        _animator.SetFloat("Speed", Mathf.Abs(displacement + _rigidBody2D.velocity.x));

        // Update the horizontal speed and direction.


        if (jump)
        {
            // Animation Controller has trigger Jump defined.
            _animator.SetTrigger("Jump");
            _rigidBody2D.velocity = new Vector2(_rigidBody2D.velocity.x, jumpForce);
            jump = false;
        }
    }

    /// <summary>
    /// Sets the speed of the player's rigidbody to the moveSpeed.
    /// </summary>
    private void SetSpeed()
    {
        _rigidBody2D.velocity = new Vector2(moveSpeed, _rigidBody2D.velocity.y);
    }

    /// <summary>
    /// Sets whether or not the player is currently grounded.
    /// </summary>
    private void SetGrounded()
    {
        grounded = Physics2D.IsTouchingLayers(_collider, groundLayerMask);
    }

    /// <summary>
    /// Checks if the player is jumping.
    /// </summary>
    private void CheckJump()
    {
        if (Input.GetButtonDown("Jump") && grounded)
        {
            jump = true;
        }
    }

    /// <summary>
    /// Updates the Player's horizontal speed by adding the argument speed with the 
    /// current speed of the player.  If the player exceeds the maximum speed,
    /// the player's speed will be forced at the maximum speed.
    /// </summary>
    /// <param name="speed">The speed to </param>
    private void UpdateHorizontalSpeed(float speed)
    {
        bool exceedsMaxSpeed = Mathf.Abs(_rigidBody2D.velocity.x + speed) > maxSpeed;
        if (exceedsMaxSpeed)
        {
            float newVelocity = Mathf.Sign(_rigidBody2D.velocity.x) * maxSpeed;
            _rigidBody2D.velocity = new Vector2(newVelocity, _rigidBody2D.velocity.y);
        }
    }
}
