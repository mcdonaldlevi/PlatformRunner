﻿using UnityEngine;
using System.Collections;

public class PlayerThrow2 : MonoBehaviour {

	public float throwForceHorz;
	public float throwForceVert;
	public Rigidbody2D rb2dthrower;
	public Rigidbody2D rb2dthrowee;
	private bool isCarried;
	public float jumpForce = 1000;
	private Animator anim;
	// Use this for initialization
	void Awake () {
		isCarried = false;
		anim = rb2dthrowee.GetComponent<Animator> ();

	}
	void Update ()
	{
		if (Mathf.Abs (rb2dthrower.transform.position.magnitude - rb2dthrowee.transform.position.magnitude) < 1.6 && Input.GetButton ("Fire2")) {

			rb2dthrowee.position = new Vector2 (rb2dthrower.position.x, rb2dthrower.position.y + 1.5f);
			isCarried = true;
			if (Input.GetButtonDown ("Jump1") && isCarried) {
				anim.SetTrigger ("Jump");
				rb2dthrowee.position = new Vector2 (rb2dthrower.position.x, rb2dthrower.position.y + 2f);
				rb2dthrowee.AddForce (new Vector2 (0f, jumpForce));
				isCarried = false;
			}

		} 
		else if (isCarried) {	


			if (Input.GetAxis ("Horizontal") == 1) {

				rb2dthrowee.AddForce (new Vector2 (throwForceHorz, throwForceVert));

			} else if (Input.GetAxis ("Horizontal") == -1) {

				rb2dthrowee.AddForce (new Vector2 (-throwForceHorz, throwForceVert));

			} else if (Input.GetAxis ("Horizontal") == 0) {

				rb2dthrowee.AddForce (new Vector2 (0, throwForceVert));

			}
			isCarried = false;
		}
	}
}	



