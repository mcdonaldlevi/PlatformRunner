﻿using UnityEngine;
using System.Collections;
[RequireComponent (typeof (Controller2D2))]
public class Player2 : MonoBehaviour {

	float moveSpeed = 6;
	float gravity = -20;
	Controller2D2 controller;

	Player1 player1;
	public float jumpHeight = 4;
	public float timeToJumpToApex = .4f;
	float accelerationTimeAirborne =.2f;
	float accelerationTimeGrounded = .1f;

	float throwRange = 2;
	float targetVelocity = 0;
	bool isCarried;
	public bool isThrown = false;
	float velocityXSmoothing;
	float jumpVelocity = 8;
	Vector3 velocity;
	void Start () {
		controller = GetComponent<Controller2D2> ();
		gravity = -(2 * jumpHeight) / Mathf.Pow (timeToJumpToApex, 2);
		jumpVelocity = Mathf.Abs (gravity) * timeToJumpToApex;
	}

	// Update is called once per frame
	void Update () {

		if(controller.collisions.above || controller.collisions.below){
			velocity.y = 0;
		}
		Vector2 input = new Vector2 (Input.GetAxisRaw ("Horizontal2"), Input.GetAxisRaw ("Vertical"));

		if (Input.GetKeyDown (KeyCode.Space) && controller.collisions.below)
			velocity.y = jumpVelocity;
		if (isThrown) {
			velocity.y = jumpVelocity;
		}
		targetVelocity = input.x * moveSpeed;
		if (isThrown) {
			targetVelocity += 100;
			isThrown = false;
		}
		velocity.x = Mathf.SmoothDamp (velocity.x, targetVelocity, ref velocityXSmoothing, (controller.collisions.below) ? accelerationTimeGrounded : accelerationTimeAirborne);
		velocity.y += gravity * Time.deltaTime;
		controller.Move (velocity * Time.deltaTime);

		if (Input.GetButton ("Fire2") && this.transform.position.magnitude - player1.transform.position.magnitude < throwRange) {
			Vector3 holdRange = new Vector3 (0, 2, 0);
			player1.transform.position = Vector3.Lerp(player1.transform.position, this.transform.position + holdRange, 1f );
			isCarried = true;
		}
		if (Input.GetButtonUp ("Fire2") && isCarried) {
			player1.isThrown = true;
		}
	}
}
