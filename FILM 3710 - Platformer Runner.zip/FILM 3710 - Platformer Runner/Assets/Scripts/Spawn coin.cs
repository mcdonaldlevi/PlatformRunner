﻿using UnityEngine;
using System.Collections;

public class Spawncoin : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
