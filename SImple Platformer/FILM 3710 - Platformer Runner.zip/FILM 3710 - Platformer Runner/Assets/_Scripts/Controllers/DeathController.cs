﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathController : MonoBehaviour
{
    public GameObject target;

    Transform _targetTransform;
    CircleCollider2D _targetCollider;
    bool _targetAwake;

    Transform platformTransform;

    // Use this for initialization
    void Start()
    {
        _targetAwake = target.activeSelf;
        _targetTransform = target.GetComponent<Transform>();
        _targetCollider = target.GetComponent<CircleCollider2D>();
        platformTransform = GetComponent<Transform>();
    }

    // Update is called once per frame
    private void Update()
    {
        SetPosition();
    }

    private void SetPosition()
    {
        platformTransform.position = new Vector3(
            _targetTransform.position.x, 
            platformTransform.position.y, 
            0);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject == target)
        {
            _targetAwake = !_targetAwake;
            target.SetActive(false);
        }
    }
}
