﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/// <summary>
/// Controls the camera movement.  Speeds up the camera in the horizontal direction 
/// every second by a given acceleration.
/// </summary>
public class CameraController : MonoBehaviour
{
    public GameObject target;                               // The player to keep in the screen.
    public float startVelocity;
    public float velocityPerSecond;

    private Rigidbody _rigidbody;                           // The camera's rigidbody.
    private float _currentVelocity;                               

    void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();
        _currentVelocity = startVelocity;
        _rigidbody.velocity = new Vector3(_currentVelocity, _rigidbody.velocity.y, _rigidbody.velocity.z);
    }

    // Update the camera position once per frame.
    void FixedUpdate()
    {
        // Check the speed doesn't exceed max speed.
        if (_rigidbody.velocity.x != _currentVelocity)
        {
            UpdateVelocity();
        }
    }

    /// <summary>
    /// Updates the velocity of the rigid body attached to the camera.
    /// 
    /// Takes the velocity currently attached to the camera.  
    /// Then it calculates the new speed of the camera.
    /// Next, it 
    /// </summary>
    void UpdateVelocity()
    {
        _rigidbody.velocity = new Vector3(
            _rigidbody.velocity.x,
            _rigidbody.velocity.y,
            _rigidbody.velocity.z);
    }
}

