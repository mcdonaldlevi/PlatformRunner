﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Pools any provided object with any amount.  
/// 
/// For the specified pooledObject field, it will require a manager that manages
/// the spawn locations of the pooled object.
/// </summary>
public class ObjectPooler : MonoBehaviour
{
    public GameObject pooledObject;                     // The game object to pool.
    public int pooledAmount;                            // The total number of game objects to pool.

    List<GameObject> _pooledObjects;

    // Use this for initialization
    void Start()
    {
        _pooledObjects = new List<GameObject>();

        // Initialize pooledAmount of pooled objects.
        for (int i = 0; i < pooledAmount; i++)
        {
            GameObject obj = Instantiate(pooledObject);
            obj.SetActive(false);
            _pooledObjects.Add(obj);
        }
    }

    public bool ContainsInactive()
    {
        for (int i = 0; i < _pooledObjects.Count; i++)
        {
            if (!_pooledObjects[i].activeInHierarchy)
            {
                return true;
            }
        }
        return false;
    }

    public GameObject GetPooledObject()
    {
        // Iterate pooledObjects
        for (int i = 0; i < _pooledObjects.Count; i++)
        {
            if (!_pooledObjects[i].activeInHierarchy)
            {
                return _pooledObjects[i];
            }
        }
        
        GameObject obj = Instantiate(pooledObject);
        obj.SetActive(false);
        _pooledObjects.Add(obj);
        return obj;
    }
}
