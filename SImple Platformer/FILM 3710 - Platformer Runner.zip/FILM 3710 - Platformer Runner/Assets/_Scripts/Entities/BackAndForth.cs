﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackAndForth : MonoBehaviour
{
    public Vector2 moveDistance;                                // The distance the enemy will move in the x or y direction.
    public Vector2 velocity;                                    // The move velocity of the enemy.

    private Transform _transform;                               // The game object's transform.
    private Rigidbody2D _rigidBody2D;                           // The game object's rigidbody2D.

    void Start()
    {
        Debug.Assert(moveDistance != default(Vector2));

        _transform = gameObject.GetComponent<Transform>();
        _rigidBody2D = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        while (gameObject.activeInHierarchy)
        {
            MoveGameObject();
        }
    }

    /// <summary>
    /// Coroutine the object moving left and right.
    /// </summary>
    private IEnumerator MoveGameObject()
    {
        yield return StartCoroutine(Move(_transform, _transform.position, moveDistance, 3.0f));
        yield return StartCoroutine(Move(_transform, _transform.position, -moveDistance, 3.0f));
    }

    private IEnumerator Move(Transform transform, Vector2 startPos, Vector2 endPos, float time)
    {
        float i = 0.0f;
        float rate = 1.0f / time;
        while (i < 1.0f)
        {
            i += Time.deltaTime * rate;
            transform.position = Vector2.Lerp(startPos, endPos, i);
            yield return null;
        }
    }
}
