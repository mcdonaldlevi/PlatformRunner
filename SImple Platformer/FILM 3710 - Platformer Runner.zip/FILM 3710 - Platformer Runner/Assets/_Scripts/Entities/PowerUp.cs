﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 
/// </summary>
public class PowerUp : MonoBehaviour
{
    // The stats can be boosted and set in inspector.
    public bool regenHealth;
    public bool doublePoints;

    // Length of the power up duration (in seconds).
    public float length = 10;


    Dictionary<string, bool> _powerUps;                 // Powerup argument for PowerUpManager.
    PowerUpManager _powerUpManager;                     // Power up manager that controls what power ups do.
    string _targetTag;                                  // The entity that this can be applied to.


    // Use this for initialization
    void Start()
    {
        InitializePowerUpBoosts();
        _powerUpManager = GetComponent<PowerUpManager>();
        _targetTag = "Player";
    }

    /// <summary>
    /// Initializes the power up
    /// </summary>
    void InitializePowerUpBoosts()
    {
        _powerUps["RegenHP"] = regenHealth;
        _powerUps["DoublePoints"] = doublePoints;
    }

    // Update is called once per frame
    void Update()
    {

    }

    // Update when an object enters the trigger box.
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            _powerUpManager.ActivatePowerUp(_powerUps, length);
        }
        // Keep game object deactivated if collision doesn't match target.
        gameObject.SetActive(false);
    }
}
